<?php


if(isset($_POST["username"]))
{
	 $uname = $_POST["username"];
  	 $password =$_POST["password"];
  	 $type = $_POST["cmbtype"];

  	 $con = mysqli_connect("localhost","root","");
  	 mysqli_select_db($con,"gear4");

  	 $sql = "SELECT * FROM users WHERE userName='$uname' and password='$password' and type='$type'";
	 $result = mysqli_query($con,$sql);

	 if($row = mysqli_fetch_array($result))
	{
		session_start();
		$_SESSION["userName"] = $uname;
		$_SESSION["type"] = $type;
		header("Location:index.php");
	}
	else
	{
		echo "Invalid username or password";
		echo "<a href=\"login.html\"><br>Go Back</a>"
		;

	}


}
?>