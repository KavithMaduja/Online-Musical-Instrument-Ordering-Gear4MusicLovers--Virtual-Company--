<?php
$itemno="00011";
$cusID="garuka111";
echo"Hello ".$cusID."<br/><br/><br/><br/>";

//database
$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"gear4");

$selectprice=mysqli_query($con,"SELECT iprice FROM instruments WHERE iCode='$itemno'");
while($price=mysqli_fetch_array($selectprice))
{

	$iprice=$price[0];
}
$selectdesc=mysqli_query($con,"SELECT iDesc FROM instruments Where iCode='$itemno'");
while($itemname=mysqli_fetch_array($selectdesc))
{
	$iname=$itemname[0];
}
//database


	

echo"<table>";
echo"<tr>";
echo"<td><b>Item name </b>".$iname."</td>";

echo"</tr>";

echo'<tr>';
echo"<td><b>Item no </b>".$itemno."</td>";

echo"</tr>";

echo"<tr>";
echo"<td><b>price Rs </b>".$iprice."</td>";

echo"</tr>";

echo"<tr>";
echo"<td>";
echo"select quantity";




echo'<form action="cart.php" method="post">';
echo '<INPUT TYPE = "text" name="txtqty" VALUE ="1" size="5">';
echo'<input type="submit" value="add" />';
echo"</form>";
echo"</td>";
echo"<td>";


?>