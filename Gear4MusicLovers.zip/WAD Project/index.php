<html>

<?php
session_start();
?>

<head>
	<title>gear grid</title>
  <script type="text/javascript" language="javascript" src="homescript.js"> </script>

  <style>

  * {
    box-sizing: border-box;
  }

  
  body {
    margin: 0;
	width: 100vw;
  }

  div.maingrid {
    display: grid;
    grid-template-areas:
	"gearlogo userinfo"
	"gearlogo userinfo"
	"gearlogo navbar"
	"search search"
	"article article"
	"iconcontainer iconcontainer"
	"iconlabel iconlabel"
	"footer footer";
    grid-template-rows: min-content min-content min-content 1fr min-content;
    grid-template-columns: 327px 1fr;
	
	min-height: 100vh;
	
	min-width: 100vw;
  }

  div.userinfo {
    grid-area: userinfo;
    background: indigo;
  }

  div.gearlogo, div.userinfo, div.navbar {
    color: whitesmoke;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 25px;
    text-align: center;
    line-height: 2em;
  }

  div.gearlogo {
    background-color: black;
    grid-area: gearlogo;
  }

  div.navbar {
    grid-area: navbar;
    background: cadetblue;

    display: flex;
    font-size: 16px;
    padding: 0;
  }
  
  div.article {
    grid-area: article;
	min-height: 100%;
	min-width: 100vw;
	background-color: gold;
	margin: 0;
	padding: 0;
  }
  
  div.footer {
    grid-area: footer;
	display: flex;
    background-color: gray;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 15px;
	margin: 0;
	padding-top: 10px;
	padding-bottom: 10px;
	line-height: 1.5em;
	
	align-self: end;
  }
  
  .navhome {
    flex-grow: 1;
    background: darkviolet;
    margin: 0;
  }

  .navcontact {
    flex-grow: 1;
    background: steelblue;
    margin: 0;
  }

  .navabout {
    flex-grow: 1;
    background: mediumorchid;
    margin: 0;
  }
  
  .footerlist {
    flex-grow: 1;
	margin: 0;
  }
  
  ul {
    list-style: none;
  }
  
  
  .search {
    display: block;
	text-align: center;
    grid-area: search;
	font-size: 20px;
	background-color: black;
  }
  
  .txtsearch {
    width: 400px;
    height: 40px;
	padding-top: 5px;
  }
  
  .srchbtn {
    font-size: 16px;
    margin-left: 10px;
    height: 40px;
	width: 80px;
  }
  
  .imggarbarek, .imgjimi, .imgyiruma {
    margin: 0;
	padding: 0;
	text-align: right;
	color: white;
	font-family: "Meiryo ui";
	font-size: 30px;
  }
  
  .imggarbarek {
    background-image: linear-gradient(to bottom, rgba(47, 121, 119, 0.45), rgba(47, 121, 119, 0.45)),url('images/Garbarek_1.jpg');
    width: 100vw;
    height: 418px;
    background-size: cover;

   }
   
   .imgjimi {
    background-image: linear-gradient(to bottom, rgba(31, 31, 193, 0.52), rgba(31, 31, 193, 0.52)),url('images/jimi_1.jpg');
    width: 100vw;
    height: 418px;
    background-size: cover;
   }
   
   .imgyiruma {
    background-image: linear-gradient(to bottom, rgba(186, 85, 211, 0.52), rgba(186, 85, 211, 0.52)),url('images/yiruma_2.jpg');
    width: 100vw;
    height: 418px;
    background-size: cover;
   }
   
   .frmsearch{
     min-width: 100vw;
   }
   
   .bannertxt {
	  margin-left: 300px;
   }
   
   .bannertxtmid{
	  text-align: left;
	  margin-right: 300px;
   }
   
   .bannertop {
	   font-size: 50px;
	   text-align: center;
   }
   
   a {
	   color: white;
   }
   
   .iconcontainer {
	grid-area: iconcontainer;
    display: flex;
	padding: 0;
	margin-top: 40px;
	margin-bottom: 10px;
  }
  
  .iconlabel {
	  grid-area: iconlabel;
	  text-align: center;
	  color: midnightblue;
	  font-family: "microsoft sans serif";
	  font-size: 24px;
	  margin-bottom: 40px;
  }
  
  .icong, .icond, .icons, .iconk {
    flex: 1;
	background-color: white;
	margin: 2px;
	min-height: 100px; 
	background-repeat: no-repeat;
	background-position: center;
  }
  
  .icong {
    background-image: url('images/guitar.jpg');
  }
  .icond {
    background-image: url('images/drums.jpg');
  }
  .icons {
    background-image: url('images/sax.jpg');
  }
  .iconk {
    background-image: url('images/keyboard.jpg');
  }

  </style> 

</head>

<body>

  <div class="maingrid">
	<div class="gearlogo"><img src="logsss_small.png"></div>
	<div class="userinfo"><a href="cart.php">Cart</a> <a href="login.html">LogIn</a>
    <?php
    if($_SESSION["type"] == "admin")
{
  echo "<a href=admin.html>Admin</a>";
  echo "<a href=logout.php>Logout</a>";
  echo "Welcome, ". $_SESSION["userName"].""; 
}
else if($_SESSION["type"] == "user")
{
  echo "<a href=logout.php>Logout</a>";
  echo "&nbsp; &nbsp; &nbsp; Welcome, ". $_SESSION["userName"].""; 
}
?>

  </div>
	<div class="navbar">
	    <div class="navhome">Categories</div>
	    <div class="navcontact"><a href="contactus.php">Contact</a></div>
	    <div class="navabout"><a href="aboutus.php">About us</a></div>
	</div>
	
	<div class="search">
	<form  name="frmsearch" method="post" action="category.php" class="frmsearch">
		
		<input type="search" placeholder="Enter Keywords here" name="search_category" id="txt_search" class="txtsearch">
					<button onclick="validate()" class="srchbtn"> Search </button> 
			
	</form> 
	</div>
	
	
	
	<div class="article">  
	 <div class="imggarbarek"><br><p class="bannertop">Create.</p><p class="bannertxt">Bring your Soul in to the music you make. We offer a wide range of musical instruments to give life to your creations</p></div>
	 
     <div class="imgjimi"><br><p class="bannertop">Express.</p><p class="bannertxtmid">The latest sound technology guranteed by our partner brands will make sure your tunes will reach ears in the best way possible.</p></div>
	 
     <div class="imgyiruma"><br><p class="bannertop">Inspire.</p><p class="bannertxt">A number of renowned artists from around the world trust in our service. Go ahead and make your mark among the best.</div>
	</div>
	
	<div class="iconcontainer">
	<div class="icong"></div>
	<div class="icond"></div>
	<div class="icons"></div>
	<div class="iconk"></div>
	</div>
	
	<div class="iconlabel">Click any icon to see what we have in store.
	</div>
	
  
	<div class="footer">
		<div class="footerlist">About  <ul><li><a href="aboutus.php">About us</a></li><li><a href="contactus.php">Contact us</a></li></ul></div>
		
		<div class="footerlist">Contact details<ul><li>Phone: +98 233 455671</li><li>Fax: +98 233 567387</li><li>gear4musiclovers@gmail.com</li></ul></div>
		
		<div class="footerlist">Account <ul><li>Cart</li><li>Logout</li></ul></div>
	</div>
	</div>

</body>

</html>