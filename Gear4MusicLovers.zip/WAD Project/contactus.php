<html>

<head>
	<title>gear grid</title>

  <style>

  * {
    box-sizing: border-box;
  }

  
  body {
    margin: 0;
  }

  div.maingrid {
    display: grid;
    grid-template-areas:
	"gearlogo userinfo"
	"gearlogo userinfo"
	"gearlogo navbar"
	"article article"
	"footer footer";
    grid-template-rows: min-content min-content min-content 1fr min-content;
    grid-template-columns: 327px 1fr;
	
	min-height: 100vh;
  }

  div.userinfo {
    grid-area: userinfo;
    background: indigo;
  }

  div.gearlogo, div.userinfo, div.navbar {
    color: whitesmoke;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 25px;
    text-align: center;
    line-height: 2em;
  }

  div.gearlogo {
    background-color: black;
    grid-area: gearlogo;
  }

  div.navbar {
    grid-area: navbar;
    background: cadetblue;

    display: flex;
    font-size: 16px;
    padding: 0;
  }
  
  div.article {
    grid-area: article;
	background-color: honeydew;
	
	min-height: 100%;
  }
  
  div.footer {
     grid-area: footer;
	display: flex;
    background-color: gray;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 15px;
	margin: 0;
	padding-top: 10px;
	padding-bottom: 10px;
	line-height: 1.5em;
	
	align-self: end;
  }
  
  .navhome {
    flex-grow: 1;
    background: darkviolet;
    margin: 0;
  }

  .navcontact {
    flex-grow: 1;
    background: steelblue;
    margin: 0;
  }

  .navabout {
    flex-grow: 1;
    background: mediumorchid;
    margin: 0;
  }
  
  .footerlist {
    flex-grow: 1;
	margin: 0;
  }
  
  ul {
    list-style: none;
  }
  
  .contactcontainer {
    display: flex;
	padding: 0;
  }
  
  .phone, .fax, .email, .write {
    flex: 1;
	margin: 4px;
	min-height: 200px;
	color: darkslategray;
	font-size: 20px;
	font-family: calibri;
	text-align: center;
	border-top-style: groove;
	border-left-style: groove;
	border-color: plum;
	border-width: 2px;
  }
  
  .tp, .rocket, .mail, .fx {
    height: 70px;
	width: 87px;
    background-repeat: no-repeat;
	background-position: cover;
	position: relative;
	margin-top: 15px;
    left: 25px;
	}
	
	.tp {
	background-image: url('images/tp.png');
	}
	
	.rocket {
	background-image: url('images/rocket.png');
	}
	
	.mail {
	background-image: url('images/mail.jpg');
	}
	
	.fx {
	background-image: url('images/fax.jpg');
	}
	
	
	
	h1.subtitle {
	  color: cadetblue;
	  font-size: 42px;
	  margin: 20px;
	}

  </style> 

</head>

<body>

  <div class="maingrid">
	<div class="gearlogo"><img src="logsss_small.png"></div>
	<div class="userinfo"><a href="cart.php">Cart</a> <a href="login.html">LogIn</a>
    <?php

      session_start();

    if($_SESSION["type"] == "admin")
{
  echo "<a href=admin.html>Admin</a>";
  echo "<a href=logout.php>Logout</a>";
  echo "Welcome, ". $_SESSION["userName"].""; 
}
else if($_SESSION["type"] == "user")
{
  echo "<a href=logout.php>Logout</a>";
  echo "&nbsp; &nbsp; &nbsp; Welcome, ". $_SESSION["userName"].""; 
}


   ?>

  </div>
	<div class="navbar">
	    <div class="navhome">Categories</div>
	    <div class="navcontact"><a href="contactus.php">Contact</a></div>
	    <div class="navabout"><a href="aboutus.php">About us</a></div>
	</div>
	<div class="article"> 
	<h1 class ="subtitle">Contact Us</h1>
  
  <div class="contactcontainer">
	<div class="phone"><div class="tp"></div>
	<h2>Call us on:</h2>
	<p> +98 233 455671</p>
	</div>
	<div class="fax"><div class="fx"></div>
	<h2>Fax:</h2>
	<p> +98 233 567387</p>
	</div>
  </div>
  
  <div class="contactcontainer">
	<div class="email"><div class="mail"></div>
	<h2>Mail us at:</h2>
	<p> gear4musiclovers@gmail.com</p>
	</div>
	<div class="write"><div class="rocket"></div>
	<h2>Write to us:</h2>
	<p>Customer care division,<br>No 13,<br>Nonexistentland.</p>
	</div>
  </div>
	</div>
	
	
	<div class="footer">
		<div class="footerlist">About  <ul><li><a href="aboutus.php">About us</a></li><li><a href="contactus.php">Contact us</a></li></ul></div>
		
		<div class="footerlist">Contact details<ul><li>Phone: +98 233 455671</li><li>Fax: +98 233 567387</li><li>gear4musiclovers@gmail.com</li></ul></div>
		
		<div class="footerlist">Account <ul><li>Cart</li><li>Logout</li></ul></div>
	</div>
	</div>

</body>

</html>