<html>

<head>
	<title>gear grid</title>

  <style>

  * {
    box-sizing: border-box;
  }
  
  body {
    margin: 0;
	max-width: 100%;
  }

  div.maingrid {
    display: flex;
	flex-wrap: wrap;
  }

  div.item {
	background-color:gold; 
	margin: 4px;
	min-width: 300px;
	text-align: center;;
	font-size: 20px;
  }
  

  </style> 

</head>

<body background="images/123.jpg">


<?php

	
	$keyword=$_POST["search_category"];
		
	$con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"gear4");
	$sql="select * from Instruments where iDesc like '%$keyword%'";
	$result = mysqli_query($con,$sql);
	
	echo "<div class=\"maingrid\">";
	
	while($row=mysqli_fetch_array($result))
	{
		echo "<div class=\"item\">";
		echo "$row[1] <br> $row[2] <br> $row[3]";
		echo "</div>";
	}
	 
	echo "</div>";
	mysqli_close($con);
	 
?>

</body>

</html>


