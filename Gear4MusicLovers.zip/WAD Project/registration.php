<?php

$con = mysqli_connect("localhost","root","");

mysqli_select_db($con,"gear4");


$User_Name =$_POST["username"];
$First_Name =$_POST["firstname"];
$Last_Name =$_POST["lastname"];
$Email =$_POST["email"];
$Mobile_No =$_POST["mobile_NO"];
$Address =$_POST["address"];
$Password =$_POST["password"];
$type = "user";


if((mysqli_num_rows(mysqli_query($con,"select * from users where userName='$User_Name'")))==1) //if username exsits provide error
{
	echo "<script type='text/javascript'>
		    alert('UserName is already exists');
		  </script>";
}

else
{
$sql1 = "Insert Into customer(userName,fName,lName,address,email,mobile) values ('$User_Name','$First_Name','$Last_Name','$Address','$Email','$Mobile_No')";//customer
$sql2 = "Insert Into users(userName,password,type) values ('$User_Name','$Password','$type')";//user


	if(mysqli_query($con,$sql1) & mysqli_query($con,$sql2))
	{
	echo "Registered";
	}
	else
	{
	echo "Not Registered";
	}
}
header("refresh:2; url=registration.html");

?>