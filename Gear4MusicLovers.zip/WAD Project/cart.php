
<?php
include 'home2.php';
$cartID ="cart006";
$quantity=$_POST['txtqty'];

$con=mysqli_connect("localhost","root","");
if(!$con)
{
	echo"Not Connected to Database";
}

if(!mysqli_select_db($con,"gear4"))
{
	echo"Database not selected";
}


$sql1="INSERT INTO cartdetails(cartID,iCode,qty,itemTotal) values('$cartID','$itemno','$quantity','10000')";
$sql2="INSERT INTO cartmaster(cartID,subTot,Total,userName)values ('$cartID','$subtotal','$total','$username')";


if(!mysqli_query($con,$sql1) & !mysqli_query($con,$sql2))
{
	echo "can't add <br/>";
}
else
{
	echo"add to the cart<br/>";
}

$subtotal=$iprice*$quantity;
echo $subtotal."<br/>";



$sql3="INSERT INTO ";
//$tot=$row[0]*$quantity;
//echo"total = ".$tot;

mysqli_close($con);




?>