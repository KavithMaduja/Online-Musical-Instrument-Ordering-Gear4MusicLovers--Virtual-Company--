function validate()
		{
		if(document.getElementById("txt_search").value=="")
			{
				alert("Category Name Cannot be blank");
 			}
		}