<html>

<head>
	<title>gear grid</title>

  <style>

  * {
    box-sizing: border-box;
  }

  
  body {
    margin: 0;
  }

  div.maingrid {
    display: grid;
    grid-template-areas:
	"gearlogo userinfo"
	"gearlogo userinfo"
	"gearlogo navbar"
	"article article"
	"footer footer";
    grid-template-rows: min-content min-content min-content 1fr min-content;
    grid-template-columns: 327px 1fr;
	
	min-height: 100vh;
  }

  div.userinfo {
    grid-area: userinfo;
    background: indigo;
  }

  div.gearlogo, div.userinfo, div.navbar {
    color: whitesmoke;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 25px;
    text-align: center;
    line-height: 2em;
  }

  div.gearlogo {
    background-color: black;
    grid-area: gearlogo;
  }

  div.navbar {
    grid-area: navbar;
    background: cadetblue;

    display: flex;
    font-size: 16px;
    padding: 0;
  }
  
  div.article {
    grid-area: article;
	background-color: honeydew;
	
	min-height: 100%;
  }
  
  div.footer {
    grid-area: footer;
	display: flex;
    background-color: gray;
    font-family: "microsoft sans serif";
    color: white;
    font-size: 15px;
	margin: 0;
	padding-top: 10px;
	padding-bottom: 10px;
	line-height: 1.5em;
	
	align-self: end;
  }
  
  .navhome {
    flex-grow: 1;
    background: darkviolet;
    margin: 0;
  }

  .navcontact {
    flex-grow: 1;
    background: steelblue;
    margin: 0;
  }

  .navabout {
    flex-grow: 1;
    background: mediumorchid;
    margin: 0;
  }
  
  .footerlist {
    flex-grow: 1;
	margin: 0;
  }
  
  ul {
    list-style: none;
  }
  
  .txtpara {
    font-family: "Lucida sans unicode";
	font-size: 20px;
	margin: 35px;
	padding-bottom: 30px;
	line-height: 1.7em;
	text-align: justify;
	border-bottom-style: dotted;
	border-bottom-color: plum;
	border-bottom-width: 2px;
  }
	
	h1.subtitle {
	  color: cadetblue;
	  font-size: 42px;
	  margin: 20px;
	}

  </style> 

</head>

<body>

  <div class="maingrid">
	<div class="gearlogo"><img src="logsss_small.png"></div>
	<div class="userinfo"><a href="cart.php">Cart</a> <a href="login.html">LogIn</a>
    <?php

      session_start();

    if($_SESSION["type"] == "admin")
{
  echo "<a href=admin.html>Admin</a>";
  echo "<a href=logout.php>Logout</a>";
  echo "Welcome, ". $_SESSION["userName"].""; 
}
else if($_SESSION["type"] == "user")
{
  echo "<a href=logout.php>Logout</a>";
  echo "&nbsp; &nbsp; &nbsp; Welcome, ". $_SESSION["userName"].""; 
}


   ?>

  </div>
  <div class="navbar">
      <div class="navhome">Categories</div>
      <div class="navcontact">Contact</div>
      <div class="navabout">About us</div>
  </div>
  
  <div class="search">
  <form  name="frmsearch" method="post" action="category.php" class="frmsearch">
    
    <input type="search" placeholder="Enter Keywords here" name="search_category" id="txt_search" class="txtsearch">
          <button onclick="validate()" class="srchbtn"> Search </button> 
      
  </form> 
  </div>
	<div class="navbar">
	    <div class="navhome">Categories</div>
	    <div class="navcontact"><a href="contactus.php">Contact</a></div>
	    <div class="navabout"><a href="aboutus.php">About us</a></div>
	</div>
	<div class="article"> 
	<h1 class ="subtitle">About Us</h1>
  
	<div class="txtpara">
	Gear4MusicLovers offers more lower price and better quality goods and services for music lovers who have ideals, ambitions and make constant efforts to realize their musical dreams!<br><br>

	Believe us, the Gear4MusicLovers online store is home to the widest selection of the best musical instruments. We are always working to bring you the lowest prices and the best deals, all with superior service. We are always on the lookout for the freshest musical innovations and we're always stocked with the newest cutting-edge technology.<br><br>

	With an unrivaled in-store experience and passionate commitment to making gear easy-to-buy, Gear4MusicLovers is all about enabling musicians and non-musicians alike to experience the almost indescribable joy that comes from playing an instrument. All we sell is the greatest feeling on earth.
  </div>
	</div>
	
	
	<div class="footer">
		<div class="footerlist">About  <ul><li><a href="aboutus.php">About us</a></li><li><a href="contactus.php">Contact us</a></li></ul></div>
		
		<div class="footerlist">Contact details<ul><li>Phone: +98 233 455671</li><li>Fax: +98 233 567387</li><li>gear4musiclovers@gmail.com</li></ul></div>
		
		<div class="footerlist">Account <ul><li>Cart</li><li>Logout</li></ul></div>
	</div>
	</div>

</body>

</html>